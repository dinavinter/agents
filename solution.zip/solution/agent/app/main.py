"""
A2A agent with SAP AI Core streaming - pure Python stdlib, zero pip dependencies.
Uses urllib.request for OAuth and http.client for streaming chat completions.
"""

import base64
import http.client
import json
import os
import ssl
import uuid
import urllib.request
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse

PORT = int(os.environ.get("PORT", "9000"))

# SAP AI Core config
SAP_TOKEN_URL = os.environ.get("SAP_TOKEN_URL", "")
SAP_CLIENT_ID = os.environ.get("SAP_CLIENT_ID", "")
SAP_CLIENT_SECRET = os.environ.get("SAP_CLIENT_SECRET", "")
SAP_AI_API_URL = os.environ.get("SAP_AI_API_URL", "")
SAP_AI_DEPLOYMENT_ID = os.environ.get("SAP_AI_DEPLOYMENT_ID", "")
OPENAI_API_VERSION = os.environ.get("OPENAI_API_VERSION", "2024-02-01")
AI_RESOURCE_GROUP = os.environ.get("AI_RESOURCE_GROUP", "default")

_cached_token = None

AGENT_CARD = {
    "name": "ai-stream-agent",
    "description": "A2A agent that streams AI completions from SAP AI Core.",
    "url": os.environ.get("AGENT_PUBLIC_URL", f"http://0.0.0.0:{PORT}/"),
    "version": "1.0.0",
    "defaultInputModes": ["text", "text/plain"],
    "defaultOutputModes": ["text", "text/plain"],
    "capabilities": {"streaming": True, "pushNotifications": False},
    "skills": [
        {
            "id": "ai-stream",
            "name": "AI Stream",
            "description": "Stream AI completions via SAP AI Core. Supports text and structured output.",
            "tags": ["ai", "stream"],
            "examples": ["Think about a random topic."],
        }
    ],
}


def _get_token():
    """Fetch OAuth2 token from SAP token endpoint using Basic auth."""
    global _cached_token
    if _cached_token:
        return _cached_token

    if not SAP_TOKEN_URL or not SAP_CLIENT_ID:
        return None

    url = f"{SAP_TOKEN_URL}?grant_type=client_credentials"
    creds = base64.b64encode(f"{SAP_CLIENT_ID}:{SAP_CLIENT_SECRET}".encode()).decode()
    data = urllib.parse.urlencode(
        {
            "client_id": SAP_CLIENT_ID,
            "client_secret": SAP_CLIENT_SECRET,
            "grant_type": "client_credentials",
        }
    ).encode()

    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": f"Basic {creds}",
        },
    )

    ctx = ssl.create_default_context()
    with urllib.request.urlopen(req, context=ctx) as resp:
        body = json.loads(resp.read())
        _cached_token = body["access_token"]
        print(f"[token] Got access token ({len(_cached_token)} chars)", flush=True)
        return _cached_token


def _stream_ai_core(prompt, system=None, temperature=0.7):
    """
    Stream chat completions from SAP AI Core using http.client (stdlib).
    Yields raw SSE lines: 'data: {...}' from the OpenAI-compatible streaming API.
    """
    token = _get_token()
    if not token:
        yield None  # signal: no AI Core config
        return

    parsed = urlparse(SAP_AI_API_URL)
    path = f"/v2/inference/deployments/{SAP_AI_DEPLOYMENT_ID}/chat/completions?api-version={OPENAI_API_VERSION}"

    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})

    body = json.dumps(
        {
            "messages": messages,
            "temperature": temperature,
            "stream": True,
        }
    ).encode()

    ctx = ssl.create_default_context()
    conn = http.client.HTTPSConnection(parsed.hostname, context=ctx)
    conn.request(
        "POST",
        path,
        body=body,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
            "ai-resource-group": AI_RESOURCE_GROUP,
        },
    )

    resp = conn.getresponse()
    if resp.status != 200:
        error_body = resp.read().decode()
        print(f"[ai-core] Error {resp.status}: {error_body}", flush=True)
        yield None
        conn.close()
        return

    # Read the streaming response line by line
    buf = ""
    while True:
        chunk = resp.read(1024)
        if not chunk:
            break
        buf += chunk.decode("utf-8", errors="replace")
        while "\n" in buf:
            line, buf = buf.split("\n", 1)
            line = line.strip()
            if line.startswith("data: "):
                data = line[6:]
                if data == "[DONE]":
                    conn.close()
                    return
                yield data

    conn.close()


class A2AHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlparse(self.path).path.rstrip("/")
        if path in (
            "/.well-known/agent.json",
            "/.well-known/agent-card.json",
            "/.well-known/agent",
        ):
            self._json_response(200, AGENT_CARD)
        elif path == "" or path == "/":
            self._json_response(200, {"status": "ok", "agent": AGENT_CARD["name"]})
        else:
            self._json_response(404, {"error": "not found"})

    def do_POST(self):
        content_len = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_len) if content_len else b""

        try:
            request = json.loads(body) if body else {}
        except json.JSONDecodeError:
            self._json_response(400, {"error": "invalid json"})
            return

        params = request.get("params", {})
        message = params.get("message", {})
        parts = message.get("parts", [])
        text = ""
        for part in parts:
            if isinstance(part, dict):
                text = part.get("text", "") or text

        task_id = str(uuid.uuid4())
        context_id = str(uuid.uuid4())

        try:
            ai_params = json.loads(text) if text else {}
        except json.JSONDecodeError:
            ai_params = {"prompt": text, "mode": "text"}

        prompt = ai_params.get("prompt", text or "Hello")
        mode = ai_params.get("mode", "text")
        system = ai_params.get("system")
        temperature = ai_params.get("temperature", 0.7)
        schema = ai_params.get("schema")

        method = request.get("method", "")
        if "stream" in method or "stream" in self.path:
            self._stream_response(
                task_id, context_id, prompt, mode, system, temperature, schema, request
            )
        else:
            self._sync_response(
                task_id, context_id, prompt, system, temperature, request
            )

    def _sync_response(self, task_id, context_id, prompt, system, temperature, request):
        """Non-streaming: collect full response, return as artifact."""
        full_text = ""
        has_ai = False
        for data in _stream_ai_core(prompt, system, temperature):
            if data is None:
                break
            has_ai = True
            try:
                chunk = json.loads(data)
                delta = chunk.get("choices", [{}])[0].get("delta", {})
                full_text += delta.get("content", "")
            except json.JSONDecodeError:
                pass

        if not has_ai:
            full_text = f"Echo (no AI Core config): {prompt}"

        self._json_response(
            200,
            {
                "jsonrpc": "2.0",
                "id": request.get("id", "1"),
                "result": {
                    "id": task_id,
                    "contextId": context_id,
                    "status": {"state": "completed"},
                    "artifacts": [
                        {
                            "artifactId": str(uuid.uuid4()),
                            "parts": [
                                {
                                    "type": "text",
                                    "text": json.dumps(
                                        {"type": "output", "output": full_text}
                                    ),
                                }
                            ],
                        }
                    ],
                },
            },
        )

    def _stream_response(
        self, task_id, context_id, prompt, mode, system, temperature, schema, request
    ):
        """Streaming: SSE events from SAP AI Core."""
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.end_headers()

        def send_sse(state, content=None, artifacts=None):
            result = {
                "id": task_id,
                "contextId": context_id,
                "status": {"state": state},
            }
            if content is not None:
                result["status"]["message"] = {
                    "role": "agent",
                    "parts": [{"type": "text", "text": content}],
                }
            if artifacts is not None:
                result["artifacts"] = artifacts
            payload = f"event: message\ndata: {json.dumps({'jsonrpc': '2.0', 'result': result})}\n\n"
            self.wfile.write(payload.encode())
            self.wfile.flush()

        # Build prompt for array mode
        actual_prompt = prompt
        if mode == "array" and schema:
            schema_str = json.dumps(schema, indent=2)
            actual_prompt = f"""{prompt}

IMPORTANT: Respond with ONLY a valid JSON array. Each element must match this schema:
{schema_str}

Output a JSON array. No markdown, no explanation, just the JSON array."""

        # Stream from AI Core
        full_text = ""
        has_ai = False

        for data in _stream_ai_core(actual_prompt, system, temperature):
            if data is None:
                break
            has_ai = True
            try:
                chunk = json.loads(data)
                delta = chunk.get("choices", [{}])[0].get("delta", {})
                token = delta.get("content", "")
                if not token:
                    continue
            except json.JSONDecodeError:
                continue

            full_text += token

            if mode == "text":
                send_sse(
                    "working", json.dumps({"type": "text-delta", "textDelta": token})
                )
            else:
                # For array mode: try incremental object extraction
                send_sse(
                    "working", json.dumps({"type": "text-delta", "textDelta": token})
                )

        if not has_ai:
            # Fallback echo if no AI Core configured
            echo = f"Echo (no AI Core): {prompt}"
            for word in echo.split(" "):
                send_sse(
                    "working",
                    json.dumps({"type": "text-delta", "textDelta": word + " "}),
                )
            full_text = echo

        # For array mode: parse the complete JSON and emit elements
        if mode == "array" and full_text:
            elements = _extract_elements(full_text)
            for el in elements:
                send_sse("working", json.dumps(el))
            output = json.dumps({"type": "output", "output": elements})
        else:
            output = json.dumps({"type": "output", "output": full_text})

        send_sse(
            "completed",
            artifacts=[
                {
                    "artifactId": str(uuid.uuid4()),
                    "parts": [{"type": "text", "text": output}],
                }
            ],
        )

    def _json_response(self, status, data):
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())

    def log_message(self, format, *args):
        pass


def _extract_elements(text):
    """Extract JSON objects from a text that should contain a JSON array."""
    elements = []
    # Try parsing as a JSON array first
    text = text.strip()
    try:
        parsed = json.loads(text)
        if isinstance(parsed, list):
            return parsed
    except json.JSONDecodeError:
        pass

    # Fallback: extract objects by brace matching
    depth = 0
    in_str = False
    escape = False
    start = -1
    for i, ch in enumerate(text):
        if escape:
            escape = False
            continue
        if ch == "\\":
            escape = True
            continue
        if ch == '"':
            in_str = not in_str
            continue
        if in_str:
            continue
        if ch == "{":
            if depth == 0:
                start = i
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0 and start >= 0:
                try:
                    elements.append(json.loads(text[start : i + 1]))
                except json.JSONDecodeError:
                    pass
                start = -1
    return elements


if __name__ == "__main__":
    # Try fetching token on startup to fail fast
    if SAP_TOKEN_URL:
        try:
            _get_token()
            print(f"[agent] SAP AI Core connected ({SAP_AI_API_URL})", flush=True)
        except Exception as e:
            print(f"[agent] WARNING: Could not get token: {e}", flush=True)
            print("[agent] Will run in echo mode", flush=True)
    else:
        print("[agent] No SAP_TOKEN_URL set, running in echo mode", flush=True)

    server = HTTPServer(("0.0.0.0", PORT), A2AHandler)
    print(f"[agent] Listening on 0.0.0.0:{PORT}", flush=True)
    server.serve_forever()
